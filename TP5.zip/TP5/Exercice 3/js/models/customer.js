class Customer {

    constructor(name, firstName, email, phoneNumber){

        this.name = name;
        this.firstName = firstName;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

}

export {Customer}